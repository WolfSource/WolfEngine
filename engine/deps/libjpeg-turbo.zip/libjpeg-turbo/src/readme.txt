make sure install
https://www.nasm.us/