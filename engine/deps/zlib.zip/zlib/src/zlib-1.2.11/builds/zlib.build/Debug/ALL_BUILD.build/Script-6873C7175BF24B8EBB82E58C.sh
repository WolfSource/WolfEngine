#!/bin/sh
make -C /Users/pooyaeimandar/Documents/github/WolfSource/Wolf.Engine/engine/deps/zlib/src/zlib-1.2.11/builds -f /Users/pooyaeimandar/Documents/github/WolfSource/Wolf.Engine/engine/deps/zlib/src/zlib-1.2.11/builds/CMakeScripts/ALL_BUILD_cmakeRulesBuildPhase.make$CONFIGURATION all
