#!/bin/bash
BASEDIR=`dirname $0`
open /Applications/Utilities/Terminal.app $BASEDIR/vulkaninfo
