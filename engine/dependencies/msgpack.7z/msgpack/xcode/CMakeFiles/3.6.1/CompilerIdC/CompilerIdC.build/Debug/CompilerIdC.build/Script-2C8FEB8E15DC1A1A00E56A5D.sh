#!/bin/sh
echo "GCC_VERSION=$GCC_VERSION"
