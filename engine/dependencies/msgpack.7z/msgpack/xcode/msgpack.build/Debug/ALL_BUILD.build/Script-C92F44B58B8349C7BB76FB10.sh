#!/bin/sh
make -C /Users/pooyaeimandar/Documents/github/WolfSource/Wolf.Engine/engine/dependencies/msgpack/xcode -f /Users/pooyaeimandar/Documents/github/WolfSource/Wolf.Engine/engine/dependencies/msgpack/xcode/CMakeScripts/ALL_BUILD_cmakeRulesBuildPhase.make$CONFIGURATION all
