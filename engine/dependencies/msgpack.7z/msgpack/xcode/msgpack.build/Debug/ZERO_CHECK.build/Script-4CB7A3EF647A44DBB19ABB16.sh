#!/bin/sh
make -C /Users/pooyaeimandar/Documents/github/WolfSource/Wolf.Engine/engine/dependencies/msgpack/xcode -f /Users/pooyaeimandar/Documents/github/WolfSource/Wolf.Engine/engine/dependencies/msgpack/xcode/CMakeScripts/ZERO_CHECK_cmakeRulesBuildPhase.make$CONFIGURATION all
