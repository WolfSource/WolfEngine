// ImGui - standalone example application for Glfw + OpenGL 3, using programmable pipeline
// If you are new to ImGui, see examples/README.txt and documentation at the top of imgui.cpp.

#pragma warning(disable:4996)

extern "C"
{
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libswscale/swscale.h>
}

#pragma comment(lib,"avformat.lib")
#pragma comment(lib,"avcodec.lib")
#pragma comment(lib,"avutil.lib")
#pragma comment(lib,"swscale.lib")
#pragma comment(lib,"swresample.lib")

//for tcp
#pragma comment (lib, "Ws2_32.lib")
#pragma comment (lib, "Mswsock.lib")
#pragma comment (lib, "AdvApi32.lib")

#include <imgui.h>
#include "imgui_impl_glfw_gl3.h"
#include <stdio.h>
#include <GL/gl3w.h>    // This example is using gl3w to access OpenGL functions (because it is small). You may use glew/glad/glLoadGen/etc. whatever already works for you.
#include <GLFW/glfw3.h>
#include <string>
#include <ppltasks.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <winsock2.h>
#include <ws2tcpip.h>

#define DEFAULT_IO_BUFLEN 13
#define DEFAULT_IO_PORT "8553"

#define W 640
#define H 480
#define SIZE    (W * H * 3)
static  uint8_t* _pixels = nullptr;
static bool _pixels_updated = false;
struct Vertex
{
    ImVec2  pos;
    ImVec2  uv;
};

const float _scale = 0.9f;
float _left = -1.0f * _scale;
float _top = -1.0f * _scale;
float _right = 1.0f * _scale;
float _down = 1.0f * _scale;

Vertex vertices[] =
{
    { ImVec2(_right, _down), ImVec2(1.0f, 0.0f) },
    { ImVec2(_left, _top)  , ImVec2(0.0f, 1.0f) },
    { ImVec2(_left, _down) , ImVec2(0.0f, 0.0f) },
    { ImVec2(_right, _top) , ImVec2(1.0f, 1.0f) } 
};

GLuint indices[] =
{
    0, 1, 2, 0, 3, 1
};

GLuint vao, vertex_buffer, index_buffer, vertex_shader, fragment_shader, program, texture;
GLint texture_location, iPos_location, iUV_location;

static const char* vertex_shader_text =
"#version 150\n"
"in vec2 i_pos;\n"
"in vec2 i_uv;\n"
"out vec2 o_uv;\n"
"void main()\n"
"{\n"
"    gl_Position = vec4(i_pos, 0.0, 1.0);\n"
"    o_uv = i_uv;\n"
"}\n";

static const char* fragment_shader_text =
"#version 150\n"
"in vec2 o_uv;\n"
"uniform sampler2D t_sampler;\n"
"void main()\n"
"{\n"
"    gl_FragColor = texture(t_sampler, o_uv);\n"
"}\n";

SwsContext* img_convert_ctx = nullptr;
AVFormatContext* format_ctx = nullptr;
AVCodecContext* codec_ctx = nullptr;
uint8_t* picture_buffer = nullptr;
AVFrame* picture = nullptr;
AVFrame* picture_rgb = nullptr;
uint8_t* picture_buffer_2 = nullptr;
AVPacket packet;
AVFormatContext* output_ctx = nullptr;
int video_stream_index = -1;
AVStream* stream = nullptr;
std::atomic<bool> StartSendingIO = false;

static void error_callback(int error, const char* description)
{
    fprintf(stderr, "Error %d: %s\n", error, description);
}

bool init_falcon();
bool init_streaming();
bool release_falcon();
bool release_streaming();

static void sendIO()
{
    while (!StartSendingIO);
    
    WSADATA wsaData;
    SOCKET ConnectSocket = INVALID_SOCKET;
    struct addrinfo *result = NULL, *ptr = NULL, hints;
    
    char recvbuf[DEFAULT_IO_BUFLEN];
    int iResult;
    int recvbuflen = DEFAULT_IO_BUFLEN;

    // Initialize Winsock
    iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != 0) {
        printf("WSAStartup failed with error: %d\n", iResult);
        return;
    }

    ZeroMemory(&hints, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;

    // Resolve the server address and port
    iResult = getaddrinfo("172.16.5.11", DEFAULT_IO_PORT, &hints, &result);
    if (iResult != 0)
    {
        printf("getaddrinfo failed with error: %d\n", iResult);
        WSACleanup();
        return;
    }

    // Attempt to connect to an address until one succeeds
    for (ptr = result; ptr != NULL; ptr = ptr->ai_next) 
    {
        // Create a SOCKET for connecting to server
        ConnectSocket = socket(
            ptr->ai_family, 
            ptr->ai_socktype,
            ptr->ai_protocol);
        if (ConnectSocket == INVALID_SOCKET) 
        {
            printf("socket failed with error: %ld\n", WSAGetLastError());
            WSACleanup();
            return;
        }

        // Connect to server.
        iResult = connect(ConnectSocket, ptr->ai_addr, (int)ptr->ai_addrlen);
        if (iResult == SOCKET_ERROR) 
        {
            closesocket(ConnectSocket);
            ConnectSocket = INVALID_SOCKET;
            continue;
        }
        break;
    }

    freeaddrinfo(result);

    if (ConnectSocket == INVALID_SOCKET) 
    {
        printf("Unable to connect to server!\n");
        WSACleanup();
        return;
    }

    // Send an initial buffer
    while (true)
    {
        auto _io = ImGui::GetIO();
        std::string sendbuf = std::to_string(_io.MousePos.x) + ":" + 
            std::to_string(_io.MousePos.y) + "\n";
        iResult = send(ConnectSocket, sendbuf.c_str(), sendbuf.size(), 0);
        if (iResult == SOCKET_ERROR)
        {
            printf("send failed with error: %d\n", WSAGetLastError());
            closesocket(ConnectSocket);
            WSACleanup();
            break;
        }
    }

    closesocket(ConnectSocket);
    WSACleanup();
}

int main(int, char**)
{
    // Setup window
    glfwSetErrorCallback(error_callback);
    if (!glfwInit())
        return 1;
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#if __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif
    GLFWwindow* window = glfwCreateWindow(W, H, "ImGui OpenGL3 example", NULL, NULL);
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1); // Enable vsync
    gl3wInit();
   

    // Setup ImGui binding
    ImGui_ImplGlfwGL3_Init(window, true);

    // Load Fonts
    // (there is a default font, this is only if you want to change it. see extra_fonts/README.txt for more details)
    //ImGuiIO& io = ImGui::GetIO();
    //io.Fonts->AddFontDefault();
    //io.Fonts->AddFontFromFileTTF("../../extra_fonts/Cousine-Regular.ttf", 15.0f);
    //io.Fonts->AddFontFromFileTTF("../../extra_fonts/DroidSans.ttf", 16.0f);
    //io.Fonts->AddFontFromFileTTF("../../extra_fonts/Roboto-Medium.ttf", 16.0f);
    //io.Fonts->AddFontFromFileTTF("../../extra_fonts/ProggyTiny.ttf", 10.0f);
    //io.Fonts->AddFontFromFileTTF("c:\\Windows\\Fonts\\ArialUni.ttf", 18.0f, NULL, io.Fonts->GetGlyphRangesJapanese());

    bool show_test_window = true;
    bool show_another_window = false;
    ImVec4 clear_color = ImVec4(0.45f, 0.55f, 0.60f, 1.00f);

    init_falcon();
    concurrency::create_task([]()
    {
        init_streaming();
        release_streaming();
    });

    concurrency::create_task([]()
    {
        sendIO();
    });

    // Main loop
    while (!glfwWindowShouldClose(window))
    {
        glfwPollEvents();
        ImGui_ImplGlfwGL3_NewFrame();

        // 1. Show a simple window
        // Tip: if we don't call ImGui::Begin()/ImGui::End() the widgets appears in a window automatically called "Debug"
        {
            static float f = 0.0f;
            ImGui::Text("Hello, Cloud Gamming!");
            ImGui::SliderFloat("float", &f, 0.0f, 1.0f);
            ImGui::ColorEdit3("clear color", (float*)&clear_color);
            if (ImGui::Button("Test Window")) show_test_window ^= 1;
            if (ImGui::Button("Another Window")) show_another_window ^= 1;
            ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);
        }

        // 2. Show another simple window, this time using an explicit Begin/End pair
        //if (show_another_window)
        //{
        //    ImGui::Begin("Another Window", &show_another_window);
        //    ImGui::Text("Hello from another window!");
        //    ImGui::End();
        //}

        //// 3. Show the ImGui test window. Most of the sample code is in ImGui::ShowTestWindow()
        //if (show_test_window)
        //{
        //    ImGui::SetNextWindowPos(ImVec2(650, 20), ImGuiCond_FirstUseEver);
        //    ImGui::ShowTestWindow(&show_test_window);
        //}

        // Rendering
        int display_w, display_h;
        glfwGetFramebufferSize(window, &display_w, &display_h);
        
		glViewport(0, 0, display_w, display_h);
        glClearColor(clear_color.x, clear_color.y, clear_color.z, clear_color.w);
        glClear(GL_COLOR_BUFFER_BIT);

        //change data of texture
        glBindTexture(GL_TEXTURE_2D, texture);
        if (_pixels_updated)
        {
            glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, W, H, GL_RGB, GL_UNSIGNED_BYTE, _pixels);
        }

        glUseProgram(program);
		glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
		
        ImGui::Render();
        
        glfwSwapBuffers(window);
    }

    // Cleanup
    release_falcon();
    ImGui_ImplGlfwGL3_Shutdown();
    glfwTerminate();

    return 0;
}

bool init_falcon()
{
    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);

    glGenBuffers(1, &vertex_buffer);
    glBindBuffer(GL_ARRAY_BUFFER, vertex_buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glGenBuffers(1, &index_buffer);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, index_buffer);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    vertex_shader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertex_shader, 1, &vertex_shader_text, NULL);
    glCompileShader(vertex_shader);

    fragment_shader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragment_shader, 1, &fragment_shader_text, NULL);
    glCompileShader(fragment_shader);

    program = glCreateProgram();
    glAttachShader(program, vertex_shader);
    glAttachShader(program, fragment_shader);
    glLinkProgram(program);
    glUseProgram(program);

	texture_location = glGetUniformLocation(program, "t_sampler");
    iPos_location = glGetAttribLocation(program, "i_pos");
    iUV_location = glGetAttribLocation(program, "i_uv");

#define OFFSETOF(TYPE, ELEMENT) ((size_t)&(((TYPE *)0)->ELEMENT))
    glEnableVertexAttribArray(iPos_location);
    glVertexAttribPointer(iPos_location, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)OFFSETOF(Vertex, pos));
    glEnableVertexAttribArray(iUV_location);
    glVertexAttribPointer(iUV_location, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)OFFSETOF(Vertex, uv));
#undef OFFSETOF

    // Create one OpenGL texture
	glActiveTexture(GL_TEXTURE0);
	glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
	glUniform1i(texture_location, 0);

    _pixels = new uint8_t[SIZE];
    for (int j = 0; j < SIZE; j += 3)
    {
        uint8_t _r = 0;
        uint8_t _g = 0;
        uint8_t _b = 0;

        if (j < SIZE / 2)
        {
            _r = 255;
            _g = 0;
            _b = 0;
        }
        else
        {
            _r = 0;
            _g = 0;
            _b = 255;
        }

        _pixels[j] = _r;
        _pixels[j + 1] = _g;
        _pixels[j + 2] = _b;
    }

    //int _ss = 0;
    //glGetIntegerv(GL_MAX_TEXTURE_SIZE, &_ss);
    //auto version = glGetString(GL_VERSION);
    //auto extensions = glGetString(GL_EXTENSIONS);

	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	//unsigned char* _data = stbi_load("E:\\SourceCode\\github\\WolfSource\\Wolf.Engine\\Logo.jpg", &x, &y, &n, 0);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, W, H, 0, GL_RGB, GL_UNSIGNED_BYTE, _pixels);
    

	////now read back
	//auto  _read = new uint8_t[_size];
	//glGetBufferSubData(GL_TEXTURE_2D, 0, _size, _read);
	//for (int j = 0; j < _size; j += 4)
	//{
	//	auto _r = _read[j];
	//	auto _g = _read[j + 1];
	//	auto _b = _read[j + 2];
	//	auto _a = _read[j + 3];
	//	/*OutputDebugStringA(std::to_string(_r).c_str());
	//	OutputDebugStringA(std::to_string(_g).c_str());
	//	OutputDebugStringA(std::to_string(_b).c_str());
	//	OutputDebugStringA(std::to_string(_a).c_str());
	//	*/
	//}

//    delete[] _read;



	glBindTexture(GL_TEXTURE_2D, 0);

	glUseProgram(0);

    return true;
}

static int interrupt_cb(void* ctx)
{
    AVFormatContext* _ctx = (AVFormatContext*)ctx;
    if (_ctx->nb_streams)
    {
       //MessageBoxA(NULL, "Connected to RTSP", "Error", 0);
    }
    return 0;
}

bool init_streaming()
{
    av_register_all();
    avcodec_register_all();
    avformat_network_init();

    
    //open RTSP
    AVDictionary* _av_dic = NULL; // "create" an empty dictionary
    av_dict_set(&_av_dic, "rtsp_flags", "listen", 0); // add an entry
    av_dict_set(&_av_dic, "timeout", "10", 0); // add an entry
    av_dict_set(&_av_dic, "rtsp_transport", "udp", 0); // add an entry

    format_ctx = avformat_alloc_context();
    format_ctx->interrupt_callback.callback = interrupt_cb;
    format_ctx->interrupt_callback.opaque = format_ctx;

    if (avformat_open_input(&format_ctx, "rtsp://172.16.4.207:8554/live.sdp", NULL, &_av_dic) != 0)
    {
        MessageBoxA(NULL, "Could not open RTSP", "Error", 0);
        return false;
    }

    StartSendingIO = true;
    if (avformat_find_stream_info(format_ctx, NULL) < 0)
    {
        return false;
    }

    //search video stream
    for (int i = 0; i < format_ctx->nb_streams; i++)
    {
        if (format_ctx->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO)
        {
            video_stream_index = i;
        }
    }
    
    av_init_packet(&packet);

    //open output file
    output_ctx = avformat_alloc_context();
            
    //start reading packets from stream and write them to file
    av_read_play(format_ctx);    //play RTSP
    auto codec = avcodec_find_decoder(AV_CODEC_ID_H264);
    if (!codec) 
    {
        exit(1);
    }
    
    // Add this to allocate the context by codec
    codec_ctx = avcodec_alloc_context3(codec);
    avcodec_get_context_defaults3(codec_ctx, codec);
    avcodec_copy_context(codec_ctx, format_ctx->streams[video_stream_index]->codec);

    if (avcodec_open2(codec_ctx, codec, NULL) < 0)
    {
        exit(1);
    }

    img_convert_ctx = sws_getContext(
        codec_ctx->width, 
        codec_ctx->height,
        codec_ctx->pix_fmt, 
        codec_ctx->width, 
        codec_ctx->height, 
        AV_PIX_FMT_RGB24,
        SWS_BICUBIC, NULL, NULL, NULL);

    int size = avpicture_get_size(
        AV_PIX_FMT_YUV420P, 
        codec_ctx->width,
        codec_ctx->height);

    picture_buffer = (uint8_t*)(av_malloc(size));
    picture = av_frame_alloc();
    picture_rgb = av_frame_alloc();

    int size2 = avpicture_get_size(
        AV_PIX_FMT_RGB24, 
        codec_ctx->width,
        codec_ctx->height);

    picture_buffer_2 = (uint8_t*)(av_malloc(size2));

    avpicture_fill(
        (AVPicture *)picture, 
        picture_buffer, 
        AV_PIX_FMT_YUV420P,
        codec_ctx->width, 
        codec_ctx->height);

    avpicture_fill(
        (AVPicture *)picture_rgb, 
        picture_buffer_2, 
        AV_PIX_FMT_RGB24,
        codec_ctx->width, 
        codec_ctx->height);

    while (av_read_frame(format_ctx, &packet) >= 0)
    {
        if (packet.stream_index == video_stream_index) 
        {   
            //packet is video
            if (stream == NULL)
            {
                //create stream in file
                stream = avformat_new_stream(
                    output_ctx,
                    format_ctx->streams[video_stream_index]->codec->codec);

                avcodec_copy_context(
                    stream->codec,
                    format_ctx->streams[video_stream_index]->codec);

                stream->sample_aspect_ratio = format_ctx->streams[video_stream_index]->codec->sample_aspect_ratio;
            }

            int check = 0;
            packet.stream_index = stream->id;
            int result = avcodec_decode_video2(codec_ctx, picture, &check, &packet);
            if (result)
            {
                sws_scale(
                    img_convert_ctx, 
                    picture->data, 
                    picture->linesize, 
                    0,
                    codec_ctx->height, 
                    picture_rgb->data, 
                    picture_rgb->linesize);

                _pixels = picture_rgb->data[0];
                _pixels_updated = true;
            }
        }
        av_free_packet(&packet);
        av_init_packet(&packet);
    }
    return true;
}

bool send_io()
{
    return true;
}

bool release_falcon()
{
    if (_pixels)
    {
        delete[] _pixels;
    }

    glDeleteTextures(1, &texture);
    glDeleteProgram(program);
    glDeleteShader(fragment_shader);
    glDeleteShader(vertex_shader);
    glDeleteBuffers(1, &vertex_buffer);
    glDeleteBuffers(1, &index_buffer);
    glDeleteVertexArrays(1, &vao);

    return true;
}

bool release_streaming()
{
    if (picture)
    {
        av_free(picture);
    }
    if (picture_rgb)
    {
        av_free(picture_rgb);
    }
    if (picture_buffer)
    {
        av_free(picture_buffer);
    }
    if (picture_buffer_2)
    {
        av_free(picture_buffer_2);
    }
    if (format_ctx)
    {
        av_read_pause(format_ctx);
    }
    if (output_ctx)
    {
        avio_close(output_ctx->pb);
        avformat_free_context(output_ctx);
    }
    return true;
}
