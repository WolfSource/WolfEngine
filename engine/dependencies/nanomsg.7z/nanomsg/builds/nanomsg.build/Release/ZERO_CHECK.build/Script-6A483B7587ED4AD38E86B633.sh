#!/bin/sh
make -C /Users/pooyaeimandar/Documents/github/WolfSource/Wolf.Engine/engine/dependencies/nanomsg/builds -f /Users/pooyaeimandar/Documents/github/WolfSource/Wolf.Engine/engine/dependencies/nanomsg/builds/CMakeScripts/ZERO_CHECK_cmakeRulesBuildPhase.make$CONFIGURATION all
