#!/bin/sh
make -C /Users/pooyaeimandar/Documents/github/WolfSource/Wolf.Engine/engine/dependencies/nanomsg/builds -f /Users/pooyaeimandar/Documents/github/WolfSource/Wolf.Engine/engine/dependencies/nanomsg/builds/CMakeScripts/ALL_BUILD_cmakeRulesBuildPhase.make$CONFIGURATION all
