--https://github.com/moteus/lua-odbc
odbc = require "odbc"
json = require ("dkjson")

CNN_DRV = {
   {Driver = '{SQL Server}'};
   {Server='192.168.0.130'};
   {Port='1433'};
   {Database='NRCSDB'};
   {Uid='Newsroom'};
   {Pwd='1qaz!QAZ'};
 };
cnn = odbc.connect(CNN_DRV)
stmt = assert(cnn:prepare("{call wire.GetSourceNews()}"))
assert(stmt:execute())
local tbl = {
  animals = { "dog", "cat", "aardvark" },
  instruments = { "سلام خویسسییس", "tromasdadsdasdbone", "th   asdda    asdasd eremin" },
  bugs = json.null,
  trees = nil
}
local str = json.encode (tbl, { indent = true })
print (str)
print(string.len(str))

-- stmt:foreach(function(a, b, c, d, e, f)
--   print(a)
--   print(b)
--   print(c)
--   print(d)
--   print(e)
--   print(f)
-- end)
