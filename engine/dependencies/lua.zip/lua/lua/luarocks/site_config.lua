local site_config = {}

site_config.LUAROCKS_PREFIX=[[C:/lua//]]
site_config.LUA_INCDIR=[[C:/lua//include]]
site_config.LUA_LIBDIR=[[C:/lua//.]]
site_config.LUA_BINDIR=[[C:/lua//.]]
site_config.LUA_INTERPRETER = [[luajit]]
site_config.LUAROCKS_SYSCONFDIR=[[C:/lua//luarocks]]
site_config.LUAROCKS_ROCKS_TREE=[[C:/lua//]]
site_config.LUAROCKS_ROCKS_SUBDIR=[[luarocks]]
site_config.LUA_DIR_SET = true
site_config.LUAROCKS_UNAME_S=[[Windows]]
site_config.LUAROCKS_UNAME_M=[[x64]]
site_config.LUAROCKS_DOWNLOADER=[[wget]]
site_config.LUAROCKS_MD5CHECKER=[[md5sum]]

return site_config
